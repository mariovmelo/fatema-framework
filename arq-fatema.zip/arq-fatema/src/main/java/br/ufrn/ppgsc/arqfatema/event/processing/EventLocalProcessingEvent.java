package br.ufrn.ppgsc.arqfatema.event.processing;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.event.Event;

public class EventLocalProcessingEvent extends EventHolder {

    public EventLocalProcessingEvent(Event event,String entrada){
        super(event,entrada);
    }
}
