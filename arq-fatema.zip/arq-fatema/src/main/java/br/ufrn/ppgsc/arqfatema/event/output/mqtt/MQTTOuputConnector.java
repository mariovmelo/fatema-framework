package br.ufrn.ppgsc.arqfatema.event.output.mqtt;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.event.EventBusCommunication;
import br.ufrn.ppgsc.arqfatema.event.input.mqtt.MQTTFactory;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.moquette.broker.Server;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.mqtt.MqttMessageBuilders;
import io.netty.handler.codec.mqtt.MqttPublishMessage;
import io.netty.handler.codec.mqtt.MqttQoS;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.eclipse.paho.client.mqttv3.IMqttClient;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.SerializationUtils;

import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;

import static br.ufrn.ppgsc.arqfatema.ArqFatemaApplication.EVENT_IN;
import static br.ufrn.ppgsc.arqfatema.ArqFatemaApplication.EVENT_OUT;
import static java.nio.charset.StandardCharsets.UTF_8;

@Component
public class MQTTOuputConnector extends EventBusCommunication {

    @Autowired
    private MQTTFactory mqttFactory;

    private String componentSource = "EventOutput";

    private static Logger log = LoggerFactory.getLogger(MQTTOuputConnector.class);

    private MeterRegistry meterRegistry;

    private Counter reqRecieved,reqSent;

    @Autowired
    private JmsTemplate jmsTemplate;

    public MQTTOuputConnector(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        initCounters();
    }

    private void initCounters() {
        reqRecieved = this.meterRegistry.counter("mqtt.recieved"); // 1 - create a counter
        reqSent = this.meterRegistry.counter("mqtt.sent"); // 1 - create a counter
    }

    private void init(){
        //Connect
        jmsTemplate.getConnectionFactory();
        this.jmsTemplate. execute(session -> {
            MessageConsumer consumer = session.createConsumer(
                    this.jmsTemplate.getDestinationResolver().resolveDestinationName(session, "foo", false));
            consumer.setMessageListener(new MessageListener() {
                @Override
                public void onMessage(Message message) {
                    byte[] payload = SerializationUtils.serialize(((EventHolder) message).getEvent());
                    outputEvent((EventHolder) message, payload);
                }
            });
            return consumer;
            }, true);
    }
    //@JmsListener(destination = EVENT_QUEUE,selector = "componentSource = 'EventStorage'")
    public void outputEvent(EventHolder eventHolder, byte[] payload){

        try{

            String entrada = eventHolder.getEntrada();

            if(entrada.equals(EventHolder.ENTRADA_UP)){
                sendOutMQTT(payload,mqttFactory.mqttClientRemoteUp(),EVENT_IN+"/UP");
            }else if(entrada.equals(EventHolder.ENTRADA_DOWN)){
                sendOutMQTT(payload,mqttFactory.mqttClientRemoteDown(),EVENT_IN+"/DOWN");
            }else{
                sendOutMQTT(payload,mqttFactory.mqttClientRemoteUp(),EVENT_IN+"/UP");
                sendOutMQTT(payload,mqttFactory.mqttClientRemoteDown(),EVENT_IN+"/DOWN");
            }

            sendOutMQTT(payload,mqttFactory.mqttClientLocal(),EVENT_OUT);

            log.info("["+componentSource+"] "+"Evento enviado por MQTT - <"+eventHolder.getEvent()+">");

        }catch (Exception ex){
            log.error("ERRO na conexão de saída MQTT.",ex);
        }
    }

    public void sendOutMQTT(byte[] myMessage,IMqttClient mqttClient,String topic) throws Exception {
        if(mqttClient != null){

            log.info("[MQTT output]Enviando Evento <-> para "+mqttClient.getServerURI());
            MqttTopic mqttTopic =  MQTTFactory.mqttClientConnect(mqttClient).getTopic(topic);
            mqttTopic.publish(createMessage(myMessage));
            log.info("[MQTT output] Fim Enviando Evento <-> para "+mqttClient.getServerURI());
            reqSent.increment();
        }
    }

    private MqttMessage createMessage(byte[] event){
        MqttMessage mqttMessage = new MqttMessage();
        mqttMessage.setPayload(event);
        mqttMessage.setQos(0);
        mqttMessage.setRetained(false);

        return mqttMessage;
    }

}
