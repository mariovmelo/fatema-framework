package br.ufrn.ppgsc.arqfatema.util;

import br.ufrn.ppgsc.event.Event;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@Component
@Scope("singleton")
public class CacheMapImpl {

    private Map<Long, Long> timesCache = new HashMap<Long, Long>();
    private Map<Long, Event> values = new HashMap<Long, Event>();

    /** Time for the elemens to keep alive in the map in milliseconds. */
    long timeToLive = 2000;

    public void setTimeToLive(long timeToLive) {
        this.timeToLive = timeToLive;
    }

    public long getTimeToLive() {

        return this.timeToLive;
    }

    public Event put(Long key, Event value) {
        values.put(key, value);
        timesCache.put(key, System.currentTimeMillis());
        return value;
    }

    public void clearExpired() {

        // Just remove if timeToLive has been set before...
        if (timeToLive > 0) {
            List<Long> keysToClear = new ArrayList<Long>();
            long currentTime = System.currentTimeMillis();

            // Check what keys to remove
            for (Entry<Long, Long> e : timesCache.entrySet()) {
                if ((currentTime - e.getValue().longValue()) > this.timeToLive) {
                    keysToClear.add(e.getKey());
                }
            }

            // Remove the expired keys
            for (Long key : keysToClear) {
                this.timesCache.remove(key);
                this.values.remove(key);
            }
        }

    }

    public void clear() {
        this.timesCache.clear();
        this.values.clear();
    }

    public boolean containsKey(Object key) {

        return this.values.containsKey(key);
    }

    public boolean containsValue(Object value) {

        return this.values.containsValue(value);
    }

    public Event get(Object key) {

        return this.values.get(key);
    }

    public boolean isEmpty() {

        return this.values.isEmpty();
    }

    public String remove(Object key) {
        String rto = null;
        if (containsKey(key)) {
            this.values.remove(key);
            this.timesCache.remove(key);
            rto = key.toString();
        }
        return rto;
    }

    public int size() {

        return this.values.size();
    }

}