package br.ufrn.ppgsc.arqfatema.domain;

import br.ufrn.ppgsc.event.Event;
import br.ufrn.ppgsc.event.utils.ByteUtils;

import java.beans.EventHandler;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public abstract class EventHolder implements Serializable {

    public static final String ENTRADA_LOCAL = "LOCAL";
    public static final String ENTRADA_UP = "UP";
    public static final String ENTRADA_DOWN = "DOWN";

    private String entrada;
    private Event event;

    private Map<String,String> props;

    private long idEvent;

    public EventHolder(){
        props = new HashMap<String, String>();
    }

    public EventHolder(Event event,String entrada){
        this();
        this.event = event;
        if(this.event != null)
            idEvent = ByteUtils.bytesToLong(this.event.getId());
        this.entrada=entrada;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
        if(this.event != null)
            idEvent = ByteUtils.bytesToLong(this.event.getId());
    }

    public String getEntrada() {
        return entrada;
    }

    public void setEntrada(String entrada) {
        this.entrada = entrada;
    }

    public Map<String,String> getProps(){
        return props;
    }

    public long getIdEvent() {
        return idEvent;
    }
}
