package br.ufrn.ppgsc.arqfatema.event;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.event.Event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import java.util.Map;

import static br.ufrn.ppgsc.arqfatema.ArqFatemaApplication.EVENT_QUEUE;
import static br.ufrn.ppgsc.arqfatema.ArqFatemaApplication.EVENT_QUEUE_LOCAL;

@Component
public class JMSEventBus {

    private static Logger log = LoggerFactory.getLogger(JMSEventBus.class);

    @Autowired
    private JmsTemplate jmsTemplate;

    public void registerEventOnTheBus(EventHolder eventHolder, String componentSource){
        //Enviar o dado através de um canal
        //Possibilitar que outros componentes possam recuperar o evento.
        //log.debug("Evento no EventBus <" + eventHolder.getEvent() + ">  da origem "+componentSource);

        jmsTemplate.send(EVENT_QUEUE_LOCAL, new MessageCreator(){
            @Override
            public Message createMessage(Session session) throws JMSException {
                Message message = session.createObjectMessage(eventHolder);
                message.setStringProperty("componentSource",componentSource);
                log.debug("Evento enviado no EventBus <" + eventHolder.getEvent() + ">");
                return message;
            }
        });
    }

    public void postEvent(EventHolder eventHolder, String component){
        jmsTemplate.send(EVENT_QUEUE_LOCAL, new MessageCreator(){

            @Override
            public Message createMessage(Session session) throws JMSException {
                Message message = session.createObjectMessage(eventHolder);
                for(Map.Entry<String,String> entry :eventHolder.getProps().entrySet())
                    message.setStringProperty(entry.getKey(),entry.getValue());
                message.setStringProperty("component",component);
                log.debug("Evento enviado no EventBus <" + eventHolder.getEvent() + ">");
                return message;
            }
        });
    }
}
