package br.ufrn.ppgsc.arqfatema.event.storage.device;

import br.ufrn.ppgsc.arqfatema.domain.AppId;
import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.event.TipoSubTipo;
import br.ufrn.ppgsc.event.Event;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.util.SerializationUtils;

import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;

public class DeviceStorage {

    @Autowired
    private JmsTemplate jmsTemplate;


    public void init(){
        this.jmsTemplate. execute(session -> {
            MessageConsumer consumer = session.createConsumer(
                    this.jmsTemplate.getDestinationResolver().resolveDestinationName(session, "foo", false));
            consumer.setMessageListener(new MessageListener() {
                @Override
                public void onMessage(Message message) {
                    processing((EventHolder) message);
                }
            });
            return consumer;
        }, true);
    }

    public Event processing(EventHolder eventHolder) {

        Event event = eventHolder.getEvent();
        ObjectMapper mapper = new ObjectMapper();
        AppId appId = null;
        try {
            appId = mapper.readValue(new String(event.getPayload()), AppId.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        Event newEvent = event.makeCopy();

        newEvent.convertTipoSubTipo(event.getTipo(), TipoSubTipo.SUB_TIPO_APP_REG_SAVE);
        newEvent.setPayload(SerializationUtils.serialize(appId));

        return newEvent;

    }
}
