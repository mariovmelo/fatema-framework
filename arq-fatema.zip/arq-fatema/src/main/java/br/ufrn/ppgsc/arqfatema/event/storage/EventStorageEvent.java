package br.ufrn.ppgsc.arqfatema.event.storage;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.event.Event;

public class EventStorageEvent extends EventHolder {

    public EventStorageEvent(Event event,String entrada){
        super(event,entrada);
    }
}
