package br.ufrn.ppgsc.arqfatema.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class NetStatMetrics {

    @Value("${netstat.command:netstat -s;}")
    private String netstat;

    private MeterRegistry meterRegistry;

    private JMXServiceURL url;

    private JMXConnector jmxc;

    private Logger logger = Logger.getLogger(this.getClass().getName());

    private AtomicLong tcpSegementRecieved = new AtomicLong(0);
    private AtomicLong tcpSegmentSent = new AtomicLong(0);

    private AtomicInteger udpPackettRecieved = new AtomicInteger(0);
    private AtomicInteger udpPacketSent = new AtomicInteger(0);

    private AtomicInteger enqueueCount = new AtomicInteger(0);
    private AtomicInteger dequeueCount = new AtomicInteger(0);

    public NetStatMetrics(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        initCounters();
    }

    public void executeStats(){
        try{
            Runtime run = Runtime.getRuntime();
            Process pr = run.exec("netstat -s");
            //pr.waitFor();
            BufferedReader buf = new BufferedReader(new InputStreamReader(pr.getInputStream()));
            StringBuffer lineBuffer = new StringBuffer();
            String line = "";
            boolean valid = false;
            int count =0;

            NetStatReader reader = new NetStatReader();

            Map<String, Integer> valores = new HashMap<>();

                Map<String,Long> metrics = reader.call();

                if(metrics.size() > 0){
                    tcpSegementRecieved.set(metrics.get("rx.bytes"));
                    tcpSegmentSent.set(metrics.get("tx.bytes"));
    //                udpPackettRecieved.set(valores.get("packets received")-udpPackettRecieved.get());
    //                udpPacketSent.set(valores.get("packets sent")-udpPacketSent.get());
                }


            pr.destroy();
        }catch (Exception e){
            logger.log(Level.SEVERE,"Erro",e);
        }

    }

    private void initCounters() {
        logger.info("Inicializando os contadores");

        meterRegistry.gauge("network.tcp.segment.recieved.qtd",tcpSegementRecieved);
        meterRegistry.gauge("network.tcp.segment.sent.qtd", tcpSegmentSent);

        meterRegistry.gauge("network.udp.package.recieved.qtd",udpPackettRecieved);
        meterRegistry.gauge("network.udp.package.sent.qtd", udpPacketSent);


    }

    @Scheduled(fixedRate = 100,initialDelay = 0)
    public void schedulingTask() {
        executeStats();
    }

    public void connect() throws Exception {

        if(jmxc == null)
            afterPropertiesSet();

        MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();

        ObjectName mxbeanName =
                new ObjectName("org.apache.activemq:type=Broker,brokerName=broker,destinationType=Topic,destinationName=.device.sensor.data");

        Number valor = (Number) mbsc.getAttribute(mxbeanName,"EnqueueCount");

        if(!valor.toString().equals("NaN")){
            enqueueCount.set(valor.intValue());
        }

        valor = (Number) mbsc.getAttribute(mxbeanName,"DequeueCount");

        if(!valor.toString().equals("NaN")){
            dequeueCount.set(valor.intValue());
        }

    }

    public void afterPropertiesSet() throws Exception {
        url = new JMXServiceURL("service:jmx:rmi://localhost:1099/jndi/rmi://localhost:1099/jmxrmi");
        jmxc = JMXConnectorFactory.connect(url, null);
    }
}