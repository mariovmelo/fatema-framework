package br.ufrn.ppgsc.arqfatema.event.output.coap;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import com.google.iot.coap.*;
import org.eclipse.californium.core.coap.CoAP;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class NewCoapOutput {

    private static Logger log = LoggerFactory.getLogger(NewCoapOutput.class);

    private EventHolder eventHolder = null;

    private byte[] payload;

    Observable observable = new Observable();

    @Value("${coap.port.out}")
    int port;

    public void initializer() throws Exception {
        LocalEndpointManager manager = new LocalEndpointManager();
        manager.lookupSocketAddress(Coap.SCHEME_UDP,"0.0.0.0",port);

        Server server = new Server(manager);

        LocalEndpoint udpEndpoint = manager.getLocalEndpointForScheme(Coap.SCHEME_UDP);

        server.addLocalEndpoint(udpEndpoint);

        Resource<InboundRequestHandler> rootResource = new Resource<>();

        InboundRequestHandler timeHandler = new InboundRequestHandler() {
            public void onInboundRequest(InboundRequest inboundRequest) {
                if (!observable.handleInboundRequest(inboundRequest) ){
                    if(eventHolder != null){
                        log.info("Enviando Evento<" + eventHolder.getEvent() + "> para : "+inboundRequest.getMessage().getRemoteSocketAddress().toString());
                        MutableMessage msg = inboundRequest.getMessage().createResponse(CoAP.ResponseCode.CHANGED.value).setPayload(payload);
                        inboundRequest.sendResponse(msg);
                        log.info("Finalizado Envio Evento<" + eventHolder.getEvent() + "> para : "+inboundRequest.getMessage().getRemoteSocketAddress().toString());
                        eventHolder = null;
                        payload = null;
                    }
                }
            }
        };

        rootResource.addChild("out-up-new", timeHandler);

        server.setRequestHandler(rootResource);
        server.start();

        log.info("CoAP server Out up! Port: "+port);
    }


    public void addEvent(EventHolder eventHolder,byte[] payload){

        this.eventHolder = eventHolder;
        this.payload = payload;
        observable.trigger();
    }
}