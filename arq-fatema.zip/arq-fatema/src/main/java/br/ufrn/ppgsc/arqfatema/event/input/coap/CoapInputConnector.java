package br.ufrn.ppgsc.arqfatema.event.input.coap;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.event.CacheEventBusCommunication;
import br.ufrn.ppgsc.arqfatema.event.processing.EventProcessingEvent;
import br.ufrn.ppgsc.event.Event;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.eclipse.californium.core.*;
import org.eclipse.californium.core.coap.CoAP;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.eclipse.californium.core.server.resources.ConcurrentCoapResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.SerializationUtils;

import javax.jms.Message;
import javax.jms.Session;


@Component
public class CoapInputConnector extends ConcurrentCoapResource {

    private CoapObserveRelation relationUP,relationDown ;

    @Autowired
    private CacheEventBusCommunication eventBus;

    private String componentSource = "EventInput";

    private static Logger log = LoggerFactory.getLogger(CoapInputConnector.class);

    @Autowired
    @Qualifier("clientRemoteUp")
    private CoapClient coapClientUp;

    @Autowired
    @Qualifier("clientRemoteDown")
    private CoapClient coapClientDown;

    private MeterRegistry meterRegistry;

    private Counter reqSuccess,reqError;

    public CoapInputConnector(MeterRegistry meterRegistry) {

        super("event-in",10);

        this.meterRegistry = meterRegistry;
        initCounters();

    }

    private void initCounters() {
        reqSuccess = this.meterRegistry.counter("coap.req", "status", "200"); // 1 - create a counter
        reqError = this.meterRegistry.counter("coap.req", "status", "500"); // 1 - create a counter
    }

    @Override
    public void handlePOST(CoapExchange exchange) {
        try{
            log.info("Evento recebido de "+exchange.getSourceAddress().getHostName()+" no CoAP Local");

            long init = System.nanoTime();
            Event event = (Event) SerializationUtils.deserialize(exchange.getRequestPayload());
            long end = System.nanoTime();
            log.info("Tempo serializar:"+(end-init));

            EventHolder eventHolder = new EventProcessingEvent(event,EventHolder.ENTRADA_LOCAL);

            eventBus.postOnMessageBus(eventHolder,componentSource);
            log.info("["+componentSource+"] "+"Evento postado no BUS <"+event+">");

            exchange.respond(CoAP.ResponseCode.VALID,"Evento enviado com Sucesso!");
            reqSuccess.increment();
        }catch (Exception e){
            exchange.respond("ERRO de Parse!");
            reqError.increment();
            log.error("["+componentSource+"] "+"Evento error no CoAP Local ",e);
        }

    }

    //@Scheduled(fixedRate = 1000)
    public void retrieveUpFaTeMA(){
        if(coapClientUp.getURI().contains("no-broker"))
           return;

        if(relationUP == null){
            boolean connected = verifyConnection(coapClientUp);

            if(!connected)
                return;
            relationUP = coapClientUp.observe(
                    new CoapHandler() {
                        @Override public void onLoad(CoapResponse response) {
                            postEvent(EventHolder.ENTRADA_UP,response.getPayload());
                            reqSuccess.increment();
                        }

                        @Override public void onError() {
                            log.error("Erro no Evento recebido no CoAP Remote UP");
                            reqError.increment();
                        }
                    });
            log.info("Remote UP connected, URL:"+coapClientUp.getURI());
        }

    }

    //@Scheduled(fixedRate = 1000)
    public void retrieveDownFaTeMA(){

        if(coapClientDown.getURI().contains("no-broker"))
            return;

        if( relationDown == null) {

            boolean connected = verifyConnection(coapClientDown);
            if(!connected)
                return;

            relationDown = coapClientDown.observe(
                    new CoapHandler() {
                        @Override
                        public void onLoad(CoapResponse response) {
                            postEvent(EventHolder.ENTRADA_DOWN, response.getPayload());
                            reqSuccess.increment();
                        }

                        @Override
                        public void onError() {
                            log.error("Erro no Evento recebido no CoAP Remote UP");
                            reqError.increment();
                        }
                    });

            log.info("Remote DOWN connected, URL:"+coapClientDown.getURI());
        }
    }

    private boolean verifyConnection(CoapClient client){
        log.info("Verificando conexão: "+client.getURI());
        boolean success = false;
        while (!success){
            try {
                CoapResponse response = client.get();

                if(response != null && response.getCode().equals(CoAP.ResponseCode.VALID)){
                    success=true;
                    log.info("Conectado: "+client.getURI());
                }
            } catch (Exception e) {
                success = false;
            }
        }
        return success;
    }

    private void postEvent(String entrada, byte[] payload){
        try{
            Event event = (Event) SerializationUtils.deserialize(payload);
            if(event != null){
                EventHolder eventHolder = new EventProcessingEvent(event,entrada);
                eventHolder.setEntrada(entrada);
                log.info("["+componentSource+"] "+"Evento recebido no CoAP Remote "+entrada+" <"+event+">");
                eventBus.postOnMessageBus(eventHolder,componentSource);
            }
        }catch (Exception e){
            log.error("Erro no parse de Evento");
        }
    }
}
