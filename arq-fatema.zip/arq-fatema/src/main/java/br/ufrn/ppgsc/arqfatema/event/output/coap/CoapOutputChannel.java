package br.ufrn.ppgsc.arqfatema.event.output.coap;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import com.google.iot.coap.*;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.coap.MediaTypeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.SerializationUtils;

@Component
public class CoapOutputChannel {

    @Value("${ft.coap.broker.remote.up:no-broker}")
    private String coapBrokerRemoteUp;

    @Value("${ft.coap.broker.remote.down:no-broker}")
    private String coapBrokerRemoteDown;

    private static Logger log = LoggerFactory.getLogger(CoapOutputChannel.class);

    private MeterRegistry meterRegistry;

    private Counter reqRecieved,reqSent;

    @Autowired
    private CoapOutputResource coapOutputResource;

    @Autowired
    private CoapOutputUP coapOutputUP;

    @Autowired
    private NewCoapOutput newCoapOutput;

    public CoapOutputChannel(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        initCounters();
    }

    private void initCounters() {
        reqRecieved = this.meterRegistry.counter("coap.req", "status","200"); // 1 - create a counter
        reqSent = this.meterRegistry.counter("coap.req", "status","500"); // 1 - create a counter
    }

    public void sendEventToNextUp(byte[] eventHolder) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(coapBrokerRemoteUp.contains("no-broker"))
                    return;

                Client coapClient = getCoapClient("coap://" + coapBrokerRemoteUp + "/event-in-up");


                try{
                    Transaction transaction = coapClient.newRequestBuilder().setPayload(eventHolder).
                            setCode(Code.METHOD_POST).setConfirmable(false).
                            addOption(Option.CONTENT_FORMAT,ContentFormat.APPLICATION_OCTET_STREAM).send();
                    log.info("[CoAP output]Enviando Evento <-> para "+coapClient.getUri());
                    //Message message = transaction.getResponse(300L);
                    log.info("[CoAP output] Fim Enviando Evento <-> para "+coapClient.getUri());
                            //+", Resposta"+message.getCode()+" - "+ Code.toString(message.getCode()));
                    reqRecieved.increment();
                }catch (Exception e){
                    log.error("Erro de conexão - UP -> "+coapClient.getUri(),e);
                    reqSent.increment();
                }
            }
        }).start();
    }

    public void sendEventToPrevDown(byte[] eventHolder) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(coapBrokerRemoteDown.contains("no-broker"))
                    return;

                Client coapClient = getCoapClient("coap://" + coapBrokerRemoteDown + "/event-in-down");
                try{
                    Transaction transaction = coapClient.newRequestBuilder().setPayload(eventHolder).
                            setCode(Code.METHOD_POST).setConfirmable(false).
                            addOption(Option.CONTENT_FORMAT,ContentFormat.APPLICATION_OCTET_STREAM).send();
                    log.info("[CoAP output]Enviando Evento <-> para "+coapClient.getUri());
                    //Message message = transaction.getResponse(300L);
                    log.info("[CoAP output] Fim Enviando Evento <-> para "+coapClient.getUri());

                    reqRecieved.increment();
                }catch (Exception e){
                    log.error("Erro de conexão - DOWN -> "+coapClient.getUri(),e);
                    reqSent.increment();
                }
            }
        }).start();
    }

    public void addEvent(EventHolder eventHolder, byte[] payload){
        try{

            String entrada = eventHolder.getEntrada();

            //log.info("Entrada: "+entrada+"/ Down:"+coapRemoteDown+coapRemoteDown.equals("no-broker")+" / UP:"+coapRemoteUp+coapRemoteUp.equals("no-broker"));
            if(entrada.equals(EventHolder.ENTRADA_UP)){
                coapOutputUP.addEvent(eventHolder,payload);
                //sendEventToNextUp(payload);
            }else if(entrada.equals(EventHolder.ENTRADA_DOWN)){
                sendEventToPrevDown(payload);
            }else{
                coapOutputUP.addEvent(eventHolder,payload);
                //sendEventToNextUp(payload);
                sendEventToPrevDown(payload);
            }

            coapOutputResource.addEvent(eventHolder,payload);
            newCoapOutput.addEvent(eventHolder,payload);
        }catch (Exception ex){
            log.error("ERRO na conexão de saída COAP.",ex);
        }
    }

    public Client getCoapClient(String url) {
        LocalEndpointManager manager = new LocalEndpointManager();
        Client coapClient = null;
        try {
            coapClient = new Client(manager,url);
        } catch (UnsupportedSchemeException e) {
            e.printStackTrace();
        }
        return coapClient;
    }
}
