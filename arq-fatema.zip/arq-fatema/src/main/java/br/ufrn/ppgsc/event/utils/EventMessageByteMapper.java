package br.ufrn.ppgsc.event.utils;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.integration.mapping.BytesMessageMapper;
import org.springframework.lang.Nullable;
import org.springframework.messaging.Message;
import org.springframework.util.SerializationUtils;

import java.util.Map;

public class EventMessageByteMapper implements BytesMessageMapper {

    protected final Log logger = LogFactory.getLog(getClass()); // NOSONAR final

    public EventMessageByteMapper() {
    }

    @Override
    public byte[] fromMessage(Message<?> message) {
        try {
            //return fromBytesPayload(ByteUtils.objToByteArray(message.getPayload()), headersToEncode);
            return SerializationUtils.serialize(message);
        } catch (Exception e) {
            throw (e);
        }
    }

    @Override
    public Message<?> toMessage(byte[] bytes, @Nullable Map<String, Object> headers) {
        Message<?> message = null;
        try {
            //message = decodeNativeFormat(bytes, headers);
            message = (Message<?>) SerializationUtils.deserialize(bytes);
            return message;
        }
        catch (@SuppressWarnings("unused") Exception e) {
            // empty
            throw  (e);
        }
    }
}
