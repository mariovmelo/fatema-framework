package br.ufrn.ppgsc.arqfatema.event.input.coap;

import com.google.iot.coap.UnsupportedSchemeException;
import org.eclipse.californium.core.CoapClient;
import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.CoapServer;
import org.eclipse.californium.elements.util.ExecutorsUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.List;
import java.util.concurrent.Executors;

@Configuration
public class CoapServerConfiguration{

    private static Logger log = LoggerFactory.getLogger(CoapServerConfiguration.class);

    @Autowired
    private List<CoapResource> connectorList;

    @Value("${coap.port:5683}")
    private int port;

    @Value("${ft.coap.broker.remote.up:no-broker}")
    private String coapBrokerRemoteUp;

    @Value("${ft.coap.broker.remote.down:no-broker}")
    private String coapBrokerRemoteDown;

    @Bean
    public CoapServer server() throws Exception {
        CoapServer server = new CoapServer(port);

        server.setExecutors(Executors.newScheduledThreadPool(4),
                ExecutorsUtil.newDefaultSecondaryScheduler("CoapServer(secondary)#"), true);

        //server.add(new CoapResource("event").add(coapInputConnector));
        for(CoapResource coapResource : connectorList){
            if(coapResource instanceof CoapInputUPConnector)
                ((CoapInputUPConnector)coapResource).handleObserver();

            server.add(coapResource);
        }

//        server.add(coapOutputConnector.getOutUp());
//        server.add(coapOutputConnector.getOutDown());
        //server.add(new CoapResource("event").add(coapOutputConnector));

        server.start();

        return server;
    }

    @Bean
    @Primary
    public CoapClient clientRemoteUp(){
        CoapClient client = new CoapClient("coap://" + coapBrokerRemoteUp + "/event-out-up");

        return client;
    }

    @Bean
    public CoapClient clientRemoteDown(){
        CoapClient client = new CoapClient("coap://" + coapBrokerRemoteDown + "/event-out-down");
        return client;
    }

}
