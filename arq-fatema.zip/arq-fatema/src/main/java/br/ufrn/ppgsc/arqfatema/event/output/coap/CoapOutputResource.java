package br.ufrn.ppgsc.arqfatema.event.output.coap;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.eclipse.californium.core.server.resources.ConcurrentCoapResource;
import org.eclipse.californium.elements.DtlsEndpointContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.SerializationUtils;

import java.util.concurrent.BlockingQueue;

@Component
public class CoapOutputResource extends ConcurrentCoapResource {

    private static Logger log = LoggerFactory.getLogger(CoapOutputResource.class);

    private EventHolder eventHolder = null;

    private byte[] payload;

    public CoapOutputResource(){
        this("out");
    }

    public CoapOutputResource(String path) {
        super(path,10);
        setObservable(true); // enable observing
        setObserveType(CoAP.Type.CON); // configure the notification type to CONs
        getAttributes().setObservable(); // mark observable in the Link-Format
    }

    @Override
    public void handleGET(CoapExchange exchange) {

        if(eventHolder != null){
            log.info("Enviando Evento<" + eventHolder.getEvent() + "> para : "+getName());
            exchange.respond(CoAP.ResponseCode.CHANGED,payload);
            log.info("Finalizado Envio Evento<" + eventHolder.getEvent() + "> para : "+"/"+getName());
            eventHolder = null;
            this.payload = null;
        }
//        else{
//            exchange.respond(CoAP.ResponseCode.VALID);
//        }
    }
    public void addEvent(EventHolder eventHolder,byte[] payload){

        this.eventHolder = eventHolder;
        this.payload = payload;
        changed();
    }
}
