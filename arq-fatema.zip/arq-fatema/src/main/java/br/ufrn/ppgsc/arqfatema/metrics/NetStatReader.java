package br.ufrn.ppgsc.arqfatema.metrics;

import com.google.common.io.LineReader;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NetStatReader {

    private static File netstat = new File("/proc/net/dev");
    private static final Pattern dline =
            //rx                                                   //tx
            //                  device_name        -bytes  packets errs  drops fifo   frame  com   mult   -bytes  packets errs  drops fifo   frame  com   mult
    Pattern.compile("^ *([A-Za-z]+[0-9]*):\\D*(\\d+)\\D+(\\d+)\\D+(\\d+)\\D+(\\d+)\\D+\\d+\\D+\\d+\\D+\\d+\\D+\\d+\\D+(\\d+)\\D+(\\d+)\\D+(\\d+)\\D+(\\d+)\\D+\\d+\\D+\\d+\\D+\\d+\\D+\\d+.*");

    private static final Logger LOG = Logger.getLogger(NetStatReader.class.getName());

    private String device_regexp = "eth0";

    public NetStatReader() throws IOException {
        //LOG.log(Level.INFO, "Sampling interfaces {0}", device_regexp);
        //netstat = new ClassPathResource("dev.netstat").getFile();
    }

    public Map<String,Long> call() throws Exception {

        Map<String,Long> metrics = new HashMap<>();
        LineReader lr = new LineReader(new FileReader(netstat));
        String l;
        while ((l = lr.readLine()) != null) {
            Matcher m = dline.matcher(l);
            if (!m.matches()) {
                continue;
            }
            String iface = m.group(1);
            if (iface.matches(device_regexp)) {
                metrics.put("rx.bytes", Long.parseLong(m.group(2)));
                metrics.put("rx.packets", Long.parseLong(m.group(3)));
                metrics.put("rx.errs", Long.parseLong(m.group(4)));
                metrics.put("rx.drop", Long.parseLong(m.group(5)));
                metrics.put("tx.bytes", Long.parseLong(m.group(6)));
                metrics.put("tx.packets", Long.parseLong(m.group(7)));
                metrics.put("tx.errs", Long.parseLong(m.group(8)));
                metrics.put("tx.drop", Long.parseLong(m.group(9)));

            }
        }
        return metrics;

    }
}
