package br.ufrn.ppgsc.arqfatema;

import br.ufrn.ppgsc.arqfatema.event.input.mqtt.MQTTInputConnector;
import br.ufrn.ppgsc.arqfatema.event.output.OutputConnector;
import br.ufrn.ppgsc.arqfatema.event.output.coap.NewCoapOutput;
import br.ufrn.ppgsc.arqfatema.event.processing.EventProcessing;
import br.ufrn.ppgsc.arqfatema.event.storage.EventStorage;
import com.google.common.eventbus.AsyncEventBus;
import com.google.common.eventbus.EventBus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.metrics.JvmMetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.LogbackMetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.SystemMetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.jmx.JmxMetricsExportAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.jdbc.DataSourcePoolMetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.web.tomcat.TomcatMetricsAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.logging.ConditionEvaluationReportLoggingListener;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executors;

@SpringBootApplication(exclude = {
		DataSourceAutoConfiguration.class,
		DataSourceTransactionManagerAutoConfiguration.class,
		HibernateJpaAutoConfiguration.class,
		DataSourcePoolMetricsAutoConfiguration.class,
		TomcatMetricsAutoConfiguration.class,
		JvmMetricsAutoConfiguration.class,
		LogbackMetricsAutoConfiguration.class,
		JmxMetricsExportAutoConfiguration.class},scanBasePackages = "br.ufrn.ppgsc")
@EnableJms
@EnableScheduling
@Order(1)
@EnableAsync
public class ArqFatemaApplication implements ApplicationRunner {

	private static Logger log = LoggerFactory.getLogger(ArqFatemaApplication.class);

	@Value("${fatema.name}")
	private String appName;

	@Autowired
	private MQTTInputConnector mqttInputConnector;

	@Autowired
	private NewCoapOutput newCoapOutput;

	@Value("${ft.mqtt.broker.local:localhost:1883}")
	private String mqttBrokerLocal;

	@Override
	public void run(ApplicationArguments applicationArguments) throws Exception {
		log.info("Spring Boot Embedded ActiveMQ Configuration Example");

		mqttInputConnector.afterPropertiesSet();

		newCoapOutput.initializer();

		//Thread.sleep(30*1000);

		registerAppInLoadTest();
		
	}

	private void registerAppInLoadTest(){
		try{
			String uri = "http://192.168.0.100:8000/?container-name=%s";
			HttpClient client = HttpClient.newHttpClient();
			HttpRequest request = HttpRequest.newBuilder()
					.uri(URI.create(String.format(uri,"arq-fatema")))
					.build();
			HttpResponse<String> response =
					client.send(request, HttpResponse.BodyHandlers.ofString());

			log.info(response.body());

		}catch (Exception e){
			log.error("Erro de registro no LoadTest");
		}

	}

	public static final String EVENT_QUEUE_LOCAL = "/local";
	public static final String EVENT_QUEUE = "/data/event";

	public static final String EVENT_OUT = EVENT_QUEUE+"/out";
	public static final String EVENT_IN = EVENT_QUEUE+"/in";

//	@Bean
//	MeterRegistryCustomizer<MeterRegistry> configurer() {
//		return (registry) -> registry.config().commonTags("application", appName);
//	}

	public static void main(String[] args) {

		ConfigurableApplicationContext context = SpringApplication.run(ArqFatemaApplication.class, args);

		context.getBean(EventProcessing.class).register();
		context.getBean(EventStorage.class).register();
		context.getBean(OutputConnector.class).register();

	}

	@Bean
	public EventBus createEventBus(){

		EventBus eventBus = new AsyncEventBus(Executors.newScheduledThreadPool(5));
		return new EventBus();
	}

}
