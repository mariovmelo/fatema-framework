package br.ufrn.ppgsc.arqfatema.event;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.util.CacheMapImpl;
import br.ufrn.ppgsc.event.utils.ByteUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Calendar;
import java.util.TimeZone;

public abstract class CacheEventBusCommunication extends EventBusCommunication {

    @Autowired
    private CacheMapImpl cacheMap;

    public void postOnMessageBus(EventHolder eventHolder, String componentSource){

        if(cacheMap.containsKey(eventHolder.getIdEvent()))
            return;

        cacheMap.put(eventHolder.getIdEvent(),eventHolder.getEvent());

        if(componentSource.equals("EventInput")){

            try {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode actualObj = mapper.readTree(eventHolder.getEvent().getPayload());

                String computername= InetAddress.getLocalHost().getHostName();
                Calendar c = Calendar.getInstance();
                c.setTimeZone(TimeZone.getTimeZone("GMT"));
                //((ObjectNode)actualObj).put(computername+"-init-time",c.getTimeInMillis());
                eventHolder.getEvent().setPayload(mapper.writeValueAsBytes(actualObj));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        super.postOnMessageBus(eventHolder,componentSource);
    }
}
