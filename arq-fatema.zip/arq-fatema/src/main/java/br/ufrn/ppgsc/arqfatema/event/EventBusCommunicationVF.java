package br.ufrn.ppgsc.arqfatema.event;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.util.CacheMapImpl;
import br.ufrn.ppgsc.event.utils.ByteUtils;
import com.google.common.eventbus.EventBus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;

public class EventBusCommunicationVF{

    @Autowired
    private EventBus eventBus;

    private static Logger log = LoggerFactory.getLogger(EventBus.class);

    public void postOnMessageBus(EventHolder eventHolder, String componentSource){

        log.info(componentSource+" = [Evento enviado no EventBus <" + eventHolder.getEvent() + ">]");

        eventBus.post(eventHolder);
        //eventBus.registerEventOnTheBus(eventHolder,componentSource);
    }

    public void postEvent(EventHolder eventHolder, String component){
        eventBus.post(eventHolder);
    }

    public void register(){
        eventBus.register(this);
    }
}
