package br.ufrn.ppgsc.arqfatema.event.input.coap;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.event.CacheEventBusCommunication;
import br.ufrn.ppgsc.arqfatema.event.processing.EventProcessingEvent;
import br.ufrn.ppgsc.event.Event;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.eclipse.californium.core.CoapResource;
import org.eclipse.californium.core.coap.CoAP;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.eclipse.californium.core.server.resources.ConcurrentCoapResource;
import org.hibernate.Cache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.SerializationUtils;


@Component
public class CoapInputDownConnector extends ConcurrentCoapResource {

    @Autowired
    private CacheEventBusCommunication eventBus;

    private String componentSource = "EventInput";

    private static Logger log = LoggerFactory.getLogger(CoapInputDownConnector.class);

    private MeterRegistry meterRegistry;

    private Counter reqSuccess,reqError;

    public CoapInputDownConnector(MeterRegistry meterRegistry) {
        super("event-in-down",10);
        this.meterRegistry = meterRegistry;
        initCounters();
    }

    private void initCounters() {
        reqSuccess = this.meterRegistry.counter("coap.req", "status", "200"); // 1 - create a counter
        reqError = this.meterRegistry.counter("coap.req", "status", "500"); // 1 - create a counter
    }

    @Override
    public void handlePOST(CoapExchange exchange) {
        try{
            log.info("Evento recebido de "+exchange.getSourceAddress().getHostName()+" no CoAP Down");

            Event event = (Event) SerializationUtils.deserialize(exchange.getRequestPayload());
            EventHolder eventHolder = new EventProcessingEvent(event,EventHolder.ENTRADA_DOWN);
            eventHolder.setEntrada(EventHolder.ENTRADA_DOWN);

            eventBus.postOnMessageBus(eventHolder,componentSource);
            log.info("["+componentSource+"] "+"Evento postado no BUS <"+event+">");
            exchange.respond(CoAP.ResponseCode.VALID,"Evento enviado com Sucesso!");
            reqSuccess.increment();
        }catch (Exception e){
            exchange.respond("ERRO de Parse!");
            reqError.increment();
            log.error("["+componentSource+"] "+"Evento error no CoAP Remote Down ",e);
        }

    }
}
