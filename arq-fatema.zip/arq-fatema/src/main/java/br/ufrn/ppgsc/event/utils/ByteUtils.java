package br.ufrn.ppgsc.event.utils;


import java.nio.ByteBuffer;

public class ByteUtils {
    //private static ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);

    public static byte[] longToBytes(long x) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.putLong(0, x);
        return buffer.array();
    }

    public static int bytesToInt(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.put(bytes, 0, bytes.length);
        buffer.flip();//need flip
        return buffer.getInt();
    }

    public static byte[] intToBytes(int x) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.putInt(0, x);
        return buffer.array();
    }

    public static long bytesToLong(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.allocate(Long.BYTES);
        buffer.put(bytes, 0, bytes.length);
        buffer.flip();//need flip
        return buffer.getLong();
    }

    public static byte[] twoIntsToOneByte(int x,int y) {
        if(x > 15 || y > 15)
            throw new RuntimeException("Invalid Operation!!!");
        int z = x << 4;
        //System.out.println(Integer.toBinaryString(z));

        int res = z | y;

       // System.out.println(Integer.toBinaryString(res));

        byte lowByte = (byte)(res & 0xFF);

        return new byte[]{lowByte};
    }

    public static int[] splitBytesToInt(byte[] value){
        byte z = value[0];
       // System.out.println(Integer.toBinaryString(z));

        int x = (byte)(z & 0x0F);

       // System.out.println(Integer.toBinaryString(x));

        z = (byte) (z>>4);
        int y = (byte)(z & 0x0F);
       // System.out.println(Integer.toBinaryString(x));

        return new int[]{x,y};
    }
}
