package br.ufrn.ppgsc.arqfatema.event.input.coap;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.event.CacheEventBusCommunication;
import br.ufrn.ppgsc.arqfatema.event.processing.EventProcessingEvent;
import br.ufrn.ppgsc.event.Event;
import com.google.iot.coap.*;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.eclipse.californium.core.*;
import org.eclipse.californium.core.coap.CoAP;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.eclipse.californium.core.server.resources.ConcurrentCoapResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.SerializationUtils;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;


@Component
public class CoapInputUPConnector extends ConcurrentCoapResource {

    @Autowired
    private CacheEventBusCommunication eventBus;

    private String componentSource = "EventInput";

    private static Logger log = LoggerFactory.getLogger(CoapInputUPConnector.class);

    private MeterRegistry meterRegistry;

    private Counter reqSuccess,reqError;

    @Value("${ft.coap.broker.remote.down:no-broker}")
    private String coapBrokerRemoteDown;

    public CoapInputUPConnector(MeterRegistry meterRegistry) throws UnsupportedSchemeException {
        super("event-in-up",10);
        this.meterRegistry = meterRegistry;
        initCounters();
    }

    private void initCounters() {
        reqSuccess = this.meterRegistry.counter("coap.req", "status", "200"); // 1 - create a counter
        reqError = this.meterRegistry.counter("coap.req", "status", "500"); // 1 - create a counter
    }

    @Override
    public void handlePOST(CoapExchange exchange) {
        try{
            log.info("Evento recebido de "+exchange.getSourceAddress().getHostName()+" no CoAP UP");

            Event event = (Event) SerializationUtils.deserialize(exchange.getRequestPayload());
            handleEvent(event);
            exchange.respond(CoAP.ResponseCode.VALID,"Evento enviado com Sucesso!");
            reqSuccess.increment();
        }catch (Exception e){
            exchange.respond("ERRO de Parse!");
            reqError.increment();
            log.error("["+componentSource+"] "+"Evento error no CoAP remote UP ",e);
        }
    }

    public void handleEvent(Event event){
            EventHolder eventHolder = new EventProcessingEvent(event,EventHolder.ENTRADA_UP);
            eventBus.postOnMessageBus(eventHolder,componentSource);
            log.info("["+componentSource+"] "+"Evento postado no BUS <"+event+">");
    }
    public void handleObserver() throws UnsupportedSchemeException {
        if(coapBrokerRemoteDown.contains("no-ref"))
            return;

        LocalEndpointManager manager = new LocalEndpointManager();

        Client client = new Client(manager, "coap://"+coapBrokerRemoteDown);

        Transaction transaction = client.newRequestBuilder()
                .changePath("/out-up-observable")
                .addOption(Option.OBSERVE)
                .send();

        transaction.registerCallback(Executors.newScheduledThreadPool(3), new Transaction.Callback() {
            public void onTransactionResponse(LocalEndpoint le, Message response) {
                if(response.getCode() == Code.RESPONSE_CHANGED){
                    log.info("Evento recebido de "+response.getRemoteSocketAddress().toString()+" no CoAP UP observable");
                    Event event = (Event) SerializationUtils.deserialize(response.getPayload());
                    handleEvent(event);
                }
            }
        });
    }
}
