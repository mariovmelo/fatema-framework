package br.ufrn.ppgsc.arqfatema.event.storage;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.event.EventBusCommunication;
import br.ufrn.ppgsc.arqfatema.event.TipoSubTipo;
import br.ufrn.ppgsc.arqfatema.event.output.EventOutputEvent;
import br.ufrn.ppgsc.event.Event;
import com.google.common.eventbus.Subscribe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import java.util.Optional;

import static br.ufrn.ppgsc.arqfatema.ArqFatemaApplication.EVENT_QUEUE_LOCAL;

@Component
public class EventStorage extends EventBusCommunication {

    private static Logger log = LoggerFactory.getLogger(EventStorage.class);

    private String componentSource="EventStorage";

    @Subscribe
    public void storage(EventStorageEvent eventHolder){
        Event event = eventHolder.getEvent();

        Event newEvent = event;

        try{
            switch (event.getSubTipo()){
                case TipoSubTipo
                        .SUB_TIPO_APP_REG_SAVE:
                    break;

                default:
                    //log.info("Nenhum dado armazenado!");
            }
        }catch(Exception e){
            e.printStackTrace();
        }

        //eventHolder.setEvent(newEvent);
        postOnMessageBus(new EventOutputEvent(event,eventHolder.getEntrada()),componentSource);
    }
}
