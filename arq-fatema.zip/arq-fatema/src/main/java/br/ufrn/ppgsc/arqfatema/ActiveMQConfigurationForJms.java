package br.ufrn.ppgsc.arqfatema;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.autoconfigure.jms.DefaultJmsListenerContainerFactoryConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.annotation.Order;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;

import javax.jms.ConnectionFactory;
import javax.jms.QueueConnectionFactory;

@Configuration
//@Order(0)
public class ActiveMQConfigurationForJms {
    public static final String LOCAL_Q = "/data/ft/event";
    public static final String REMOTE_Q = "/data/ft/event";

    @Value("${ft.mqtt.broker.local:localhost:1883}")
    private String mqttBrokerLocal;

    @Value("${ft.jms.broker.local:localhost:5671}")
    private String jmsBrokerLocal;

    @Value("${ft.amqp.broker.local:localhost:6601}")
    private String amqpBrokerLocal;

    @Bean
    public BrokerService broker() throws Exception {
        final BrokerService broker = new BrokerService();
        //broker.addConnector("tcp://"+jmsBrokerLocal);
        broker.addConnector("mqtt://"+mqttBrokerLocal);
        //broker.addConnector("amqp://"+amqpBrokerLocal);
        broker.setUseJmx(true);
        broker.setBrokerName("broker");
        return broker;
    }

//    @Bean
//    @Primary
    public ConnectionFactory jmsConnectionFactory() {
        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://"+jmsBrokerLocal);
        connectionFactory.setTrustAllPackages(true);
        connectionFactory.setMaxThreadPoolSize(5);
        return connectionFactory;
    }

//    @Bean
//    @Primary
    public JmsTemplate jmsTemplate() {
        JmsTemplate jmsTemplate = new JmsTemplate();
        jmsTemplate.setConnectionFactory(jmsConnectionFactory());
        jmsTemplate.setDefaultDestinationName(LOCAL_Q);
        return jmsTemplate;
    }

    //@Bean
    public JmsListenerContainerFactory<?> jmsListenerContainerFactory(ConnectionFactory connectionFactory,
                                                                      DefaultJmsListenerContainerFactoryConfigurer configurer) {
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        configurer.configure(factory, connectionFactory);
        return factory;
    }
}
