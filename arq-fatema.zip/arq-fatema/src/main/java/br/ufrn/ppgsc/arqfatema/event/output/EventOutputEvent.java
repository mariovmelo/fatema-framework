package br.ufrn.ppgsc.arqfatema.event.output;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.event.Event;

public class EventOutputEvent extends EventHolder {

    public EventOutputEvent(Event event,String entrada){
        super(event,entrada);
    }
}
