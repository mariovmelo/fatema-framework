package br.ufrn.ppgsc.arqfatema.event.input.mqtt;

import org.eclipse.paho.client.mqttv3.IMqttClient;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class MQTTFactory {

    private static Logger log = LoggerFactory.getLogger(MQTTFactory.class);

    @Value("${ft.mqtt.broker.local:localhost:1883}")
    private String mqttBrokerLocal;
    @Value("${ft.mqtt.broker.remote.up:no-broker}")
    private String mqttBrokerRemoteUp;
    @Value("${ft.mqtt.broker.remote.down:no-broker}")
    private String mqttBrokerRemoteDown;

    private boolean brokerUpActive = true;
    private boolean brokerDownActive = true;

    private IMqttClient mqttClientLocal, mqttClientRemoteUp,mqttClientRemoteDown;

//    @Bean
//    @DependsOn("broker")
//    @Primary
    public IMqttClient mqttClientLocal() throws MqttException {
        String hostname = "192.168.0.21";
        String port = "1883";
        String clientId = "MQTT_PHD_Client";

        if(mqttClientLocal == null){
            mqttClientLocal = new MqttClient("tcp://" + mqttBrokerLocal, MqttClient.generateClientId());
            mqttClientLocal.connect(mqttConnectOptions());
        }

        return mqttClientLocal;
    }

//    @Bean
//    @DependsOn("broker")
    public IMqttClient mqttClientRemoteUp() throws Exception {
        try{
            if(mqttClientRemoteUp == null){
                if(mqttBrokerRemoteUp.equals("no-broker")){
                    brokerUpActive = false;
                    return null;
                }

                mqttClientRemoteUp = new MqttClient("tcp://" + mqttBrokerRemoteUp, MqttClient.generateClientId());

                validateConnection(mqttClientRemoteUp);
            }

            return mqttClientRemoteUp;
        }catch(Exception e){
            return null;
        }

    }

//    @Bean
//    @DependsOn("broker")
    public IMqttClient mqttClientRemoteDown() throws Exception {
        try{
            if(mqttClientRemoteDown == null){
                if(mqttBrokerRemoteDown.equals("no-broker")){
                    brokerDownActive = false;
                    return null;
                }

                mqttClientRemoteDown = new MqttClient("tcp://" + mqttBrokerRemoteDown, MqttClient.generateClientId());
                validateConnection(mqttClientRemoteDown);
            }

            return mqttClientRemoteDown;
        }catch (Exception e){
            return null;
        }

    }

    private void validateConnection(IMqttClient mqttClient) throws Exception {
        int count=0;
        while(count < 120){
            try{
                mqttClient.connect(mqttConnectOptions());
                count = 90;
            }catch (Exception e){
                Thread.sleep(1000);
                log.info("Tentando conectar: "+mqttClient.getServerURI());
                count++;

            }
        }
    }

//    @Bean
//    @DependsOn("broker")
//    @ConfigurationProperties(prefix = "mqtt")
    public MqttConnectOptions mqttConnectOptions() {
        return new MqttConnectOptions();
    }

    public static IMqttClient mqttClientConnect(IMqttClient mqttClient) throws Exception {
        try{
            if(!mqttClient.isConnected())
                mqttClient.connect();

            return mqttClient;
        }catch (Exception e){
            log.error("Erro ao conectar-se ao cliente "+mqttClient.getServerURI(),e);
            throw e;
        }

    }

    public boolean isBrokerUpActive(){
        return brokerUpActive;
    }
    public boolean isBrokerDownActive(){
        return brokerDownActive;
    }
}

