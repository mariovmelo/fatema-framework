package br.ufrn.ppgsc.arqfatema.event;

public class TipoSubTipo {

    public static final int TIPO_CONTROLE = 1;
    public static final int TIPO_NOTIFICACAO = 2;






    public static final int SUB_TIPO_APP_REG = 1;
    public static final int SUB_TIPO_APP_REG_SAVE = 11;

    public static final int SUB_TIPO_APP_REG_RESP = 5;

    public static final int SUB_TIPO_FALHA_DEVICE = 2;
    public static final int SUB_TIPO_FALHA_DEVICE_RESOLVED = 3;

    public static final int SUB_TIPO_APP_REG_VALUE = 3;
    public static final int SUB_TIPO_APP_REG_VALUE_RESP = 4;

    public static final int SUB_TIPO_SUBSCRIBE = 5;

}
