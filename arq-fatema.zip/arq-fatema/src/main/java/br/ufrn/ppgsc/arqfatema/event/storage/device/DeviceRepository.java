package br.ufrn.ppgsc.arqfatema.event.storage.device;

import br.ufrn.ppgsc.arqfatema.domain.AppId;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface DeviceRepository extends CrudRepository<Object,Long>{

    @Query("From Device where cod = :cod")
    public Object buscarPorCod(String cod);
}
