package br.ufrn.ppgsc.arqfatema.event.processing;

import br.ufrn.ppgsc.arqfatema.event.EventBusCommunication;
import br.ufrn.ppgsc.arqfatema.event.storage.EventStorageEvent;
import br.ufrn.ppgsc.event.Event;
import com.google.common.eventbus.Subscribe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class EventProcessing extends EventBusCommunication {

    private static Logger log = LoggerFactory.getLogger(EventProcessing.class);

    private String componentSource="EventProcessing";

    public EventProcessing(){
        super();
    }

    @Subscribe
    public void processing(EventProcessingEvent eventHolder){
        Event event = eventHolder.getEvent();

        try {
//            eventHolder.setEvent(event);
//            eventHolder.getProps().put("tipo",event.getTipo()+"");
//            eventHolder.getProps().put("subtipo",event.getSubTipo()+"");
            postEvent(new EventLocalProcessingEvent(event,eventHolder.getEntrada()),componentSource);
            postOnMessageBus(new EventStorageEvent(event,eventHolder.getEntrada()),componentSource);

        } catch (Exception ex) {
            log.error("ERRO no tratamento da mensagens.",ex);
        }
    }
}
