package br.ufrn.ppgsc.arqfatema.event.output.coap;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import com.google.iot.coap.*;
import org.eclipse.californium.core.CoapResponse;
import org.eclipse.californium.core.coap.CoAP;
import org.eclipse.californium.core.server.resources.CoapExchange;
import org.eclipse.californium.core.server.resources.ConcurrentCoapResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class CoapOutputUP extends ConcurrentCoapResource{

    private static Logger log = LoggerFactory.getLogger(CoapOutputUP.class);

    private EventHolder eventHolder = null;

    private byte[] payload;

    public CoapOutputUP(){
        this("out-up-observable");
    }

    public CoapOutputUP(String path) {
        super(path,10);
        setObservable(true); // enable observing
        setObserveType(CoAP.Type.CON); // configure the notification type to CONs
        getAttributes().setObservable(); // mark observable in the Link-Format
    }

    @Override
    public void handleGET(CoapExchange exchange) {

        if(eventHolder != null){
            log.info("Enviando Evento<" + eventHolder.getEvent() + "> para : "+getName());
            exchange.respond(CoAP.ResponseCode.CHANGED,payload);
            log.info("Finalizado Envio Evento<" + eventHolder.getEvent() + "> para : "+"/"+getName());
            eventHolder = null;
            this.payload = null;
        }
//        else{
//            exchange.respond(CoAP.ResponseCode.VALID);
//        }
    }
    public void addEvent(EventHolder eventHolder,byte[] payload){

        this.eventHolder = eventHolder;
        this.payload = payload;
        changed();
    }
}
