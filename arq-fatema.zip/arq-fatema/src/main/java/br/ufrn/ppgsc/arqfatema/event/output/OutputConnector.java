package br.ufrn.ppgsc.arqfatema.event.output;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.event.EventBusCommunication;
import br.ufrn.ppgsc.arqfatema.event.output.coap.CoapOutputChannel;
import br.ufrn.ppgsc.arqfatema.event.output.mqtt.MQTTOuputConnector;
import br.ufrn.ppgsc.event.Event;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.eventbus.Subscribe;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;
import org.springframework.util.SerializationUtils;

import java.io.IOException;
import java.net.InetAddress;
import java.util.Calendar;
import java.util.TimeZone;

import static br.ufrn.ppgsc.arqfatema.ArqFatemaApplication.EVENT_QUEUE_LOCAL;

@Component
public class OutputConnector extends EventBusCommunication {

    private String componentSource = "EventOutput";

    private static Logger log = LoggerFactory.getLogger(MQTTOuputConnector.class);


    @Autowired
    private MQTTOuputConnector mqttOuputConnector;

    @Autowired
    private CoapOutputChannel coapOutputChannel;

    @Subscribe
    public void outputEvent(EventOutputEvent eventHolder){


        ObjectMapper mapper = new ObjectMapper();
        JsonNode actualObj = null;
        try {
            log.info(InetAddress.getLocalHost().getCanonicalHostName()+" - "+InetAddress.getLocalHost().toString()+" - "+InetAddress.getLocalHost().getHostAddress());
            String computername= InetAddress.getLocalHost().getHostName();
            actualObj = mapper.readTree(eventHolder.getEvent().getPayload());
            Calendar c = Calendar.getInstance();
            c.setTimeZone(TimeZone.getTimeZone("GMT"));
            //((ObjectNode)actualObj).put(computername+"-end-time",c.getTimeInMillis());
            eventHolder.getEvent().setPayload(mapper.writeValueAsBytes(actualObj));

        } catch (IOException e) {
            e.printStackTrace();
        }

        byte payload[] = SerializationUtils.serialize(eventHolder.getEvent());

        coapOutputChannel.addEvent(eventHolder,payload);
        mqttOuputConnector.outputEvent(eventHolder,payload);

    }
}
