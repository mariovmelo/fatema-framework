package br.ufrn.ppgsc.arqfatema.event.input.mqtt;

import br.ufrn.ppgsc.arqfatema.domain.EventHolder;
import br.ufrn.ppgsc.arqfatema.event.CacheEventBusCommunication;
import br.ufrn.ppgsc.arqfatema.event.processing.EventProcessingEvent;
import br.ufrn.ppgsc.event.Event;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.SerializationUtils;

import static br.ufrn.ppgsc.arqfatema.ArqFatemaApplication.*;

@Component
public class MQTTInputConnector extends CacheEventBusCommunication{

    @Autowired
    private MQTTFactory factory;

    //private IMqttClient mqttClientLocal;

    @Autowired
    private MQTTFactory mqttFactory;

    private String componentSource = "EventInput";

    private static Logger log = LoggerFactory.getLogger(MQTTInputConnector.class);

    private MeterRegistry meterRegistry;

    private Counter reqRecieved,reqSent;

    public MQTTInputConnector(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        initCounters();
    }

    private void initCounters() {
        reqRecieved = this.meterRegistry.counter("mqtt.recieved"); // 1 - create a counter
        reqSent = this.meterRegistry.counter("mqtt.sent"); // 1 - create a counter
    }

    @Async
    public void afterPropertiesSet() throws Exception {

        MQTTFactory.mqttClientConnect(factory.mqttClientLocal()).subscribeWithResponse(EVENT_IN, ((topic, message) -> {
            Event event = (Event) SerializationUtils.deserialize(message.getPayload());
            EventHolder eventHolder = new EventProcessingEvent(event,EventHolder.ENTRADA_LOCAL);
            eventHolder.setEntrada(EventHolder.ENTRADA_LOCAL);
            log.info("["+componentSource+"] "+"Evento recebido no MQTT Local["+topic+"] - <"+event+">");
            postOnMessageBus(eventHolder,componentSource);
            reqRecieved.increment();
        }));

        if(mqttFactory.isBrokerUpActive()){
            MQTTFactory.mqttClientConnect(factory.mqttClientLocal()).subscribeWithResponse(EVENT_IN+"/UP", ((topic, message) -> {
                Event event = (Event) SerializationUtils.deserialize(message.getPayload());
                EventHolder eventHolder = new EventProcessingEvent(event,EventHolder.ENTRADA_UP);
                eventHolder.setEntrada(EventHolder.ENTRADA_UP);
                log.info("["+componentSource+"] "+"Evento recebido no MQTT Remoto UP["+topic+"] - <"+event+">");
                postOnMessageBus(eventHolder,componentSource);
                reqRecieved.increment();
            }));
        }

        if(mqttFactory.isBrokerDownActive()){
            MQTTFactory.mqttClientConnect(factory.mqttClientLocal()).subscribeWithResponse(EVENT_IN+"/DOWN", ((topic, message) -> {
                Event event = (Event) SerializationUtils.deserialize(message.getPayload());
                EventHolder eventHolder = new EventProcessingEvent(event,EventHolder.ENTRADA_DOWN);
                eventHolder.setEntrada(EventHolder.ENTRADA_DOWN);
                log.info("["+componentSource+"] "+"Evento recebido no MQTT Remoto Down["+topic+"] - <"+event+">");
                postOnMessageBus(eventHolder,componentSource);
                reqRecieved.increment();
            }));
        }
    }
}
