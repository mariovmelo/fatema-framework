package br.ufrn.ppgsc.event;

import br.ufrn.ppgsc.event.utils.ByteUtils;
import br.ufrn.ppgsc.event.utils.SequenceGenerator;
import org.springframework.beans.BeanUtils;

import java.io.Serializable;

public class Event implements Serializable {

    public static final int DIRECAO_CIMA = 2;
    public static final int DIRECAO_BAIXA = 1;

    private byte[] id;
    private byte[] tipoSubtipo;
    private byte[] provavelDestino;
    private byte[] origem;
    private byte[] direcao;
    private byte[] payload;
    public Event() {
        generateId();
    }

    public Event(boolean blank) {
        converterDirecao(0);
    }

    private void generateId(){
        long idL = SequenceGenerator.getInstance().nextId();
        id = ByteUtils.longToBytes(idL);
        converterDirecao(0);
    }

    public void convertTipoSubTipo(int tipo, int subtipo) {
        this.tipoSubtipo = ByteUtils.twoIntsToOneByte(subtipo,tipo);
    }

    public void convertProvavelDestino(long nodeId) {
        this.provavelDestino = ByteUtils.longToBytes(nodeId);
    }

    public void convertOrigem(long nodeId) {
        this.origem = ByteUtils.longToBytes(nodeId);
    }

    public void converterDirecao(int direcao){
        this.direcao = ByteUtils.intToBytes(direcao);
    }
    public long getProvavelDestinoId(){
        return ByteUtils.bytesToLong(provavelDestino);
    }
    public long getOrigemId(){
        return ByteUtils.bytesToLong(origem);
    }

    public int getDirecaoId(){
        return ByteUtils.bytesToInt(direcao);
    }

    public byte[] getDirecao() {
        return direcao;
    }

    public void setDirecao(byte[] direcao) {
        this.direcao = direcao;
    }

    public void insertPayload(String value){
        payload = value.getBytes();
    }

    public byte[] getId() {
        return id;
    }

    public void setId(byte[] id) {
        this.id = id;
    }

    public byte[] getTipoSubtipo() {
        return tipoSubtipo;
    }

    public void setTipoSubtipo(byte[] tipoSubtipo) {
        this.tipoSubtipo = tipoSubtipo;
    }

    public byte[] getProvavelDestino() {
        return provavelDestino;
    }

    public void setProvavelDestino(byte[] provavelDestino) {
        this.provavelDestino = provavelDestino;
    }

    public byte[] getOrigem() {
        return origem;
    }

    public void setOrigem(byte[] origem) {
        this.origem = origem;
    }

    public byte[] getPayload() {
        return payload;
    }

    public void setPayload(byte[] payload) {
        this.payload = payload;
    }

    public int getTipo(){
        return ByteUtils.splitBytesToInt(tipoSubtipo)[0];
    }
    public int getSubTipo(){
        return ByteUtils.splitBytesToInt(tipoSubtipo)[1];
    }

    @Override
    public String toString() {
        String saida = "id:";
        try{
            saida+=ByteUtils.bytesToLong(id);
        }catch (Exception e){

        }
        saida+=" - Tipo/Subtipo:";
        try{
            saida+=getTipo();
            saida+="/";
            saida+=getSubTipo();
        }catch (Exception e){

        }
        saida+=" - Payload:";
        try{
            saida+=new String(payload);
        }catch (Exception e){

        }

        return saida;
    }

    public Event makeCopy(){
        Event newEvent = new Event(true);
        BeanUtils.copyProperties(this,newEvent);
        long newIdL = SequenceGenerator.getInstance().nextId();
        byte[] newId = ByteUtils.longToBytes(newIdL);

        newEvent.setId(newId);

        return newEvent;
    }
}