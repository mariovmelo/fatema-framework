package br.ufrn.ppgsc.arqfatema;


class ArqFatemaApplicationTests {


	void contextLoads() {
	}

}
